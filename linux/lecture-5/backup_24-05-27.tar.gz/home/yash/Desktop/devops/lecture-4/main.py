while True:
    print("Hello world")
