read name;
echo "Hello $name"
